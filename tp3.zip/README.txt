Arquivo zip gerado em: 14/03/2023 16:04:20 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho Prático III